<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_e7bed73c0595067804721e2412931a8d1a7ef4554d235624e5255378bd30de4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e1dbbea2549cecc7e2c022872552fe93ff344d909da51405efa8188c7814f75 = $this->env->getExtension("native_profiler");
        $__internal_7e1dbbea2549cecc7e2c022872552fe93ff344d909da51405efa8188c7814f75->enter($__internal_7e1dbbea2549cecc7e2c022872552fe93ff344d909da51405efa8188c7814f75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_7e1dbbea2549cecc7e2c022872552fe93ff344d909da51405efa8188c7814f75->leave($__internal_7e1dbbea2549cecc7e2c022872552fe93ff344d909da51405efa8188c7814f75_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */

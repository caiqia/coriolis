<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_2cb1284f030752d719dc4b847306ba91f2a199dc984338ad8d2a2add329b6456 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_261f08c04d0048a723430f2d5f5e7aff65cde898af74a211698b52c06a4c7b3c = $this->env->getExtension("native_profiler");
        $__internal_261f08c04d0048a723430f2d5f5e7aff65cde898af74a211698b52c06a4c7b3c->enter($__internal_261f08c04d0048a723430f2d5f5e7aff65cde898af74a211698b52c06a4c7b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_261f08c04d0048a723430f2d5f5e7aff65cde898af74a211698b52c06a4c7b3c->leave($__internal_261f08c04d0048a723430f2d5f5e7aff65cde898af74a211698b52c06a4c7b3c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */

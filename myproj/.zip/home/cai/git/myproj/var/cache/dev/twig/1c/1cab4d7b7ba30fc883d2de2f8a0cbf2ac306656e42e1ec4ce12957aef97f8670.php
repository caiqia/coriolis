<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_fc0baf0d4d89466bbc07e8924d18cc42ca699924700900be4853b9646bd12079 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_982cabbb8792ebfd9a6908424345d26a0e3f0ec7b64f31fb9542e5789e40ba4a = $this->env->getExtension("native_profiler");
        $__internal_982cabbb8792ebfd9a6908424345d26a0e3f0ec7b64f31fb9542e5789e40ba4a->enter($__internal_982cabbb8792ebfd9a6908424345d26a0e3f0ec7b64f31fb9542e5789e40ba4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_982cabbb8792ebfd9a6908424345d26a0e3f0ec7b64f31fb9542e5789e40ba4a->leave($__internal_982cabbb8792ebfd9a6908424345d26a0e3f0ec7b64f31fb9542e5789e40ba4a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */

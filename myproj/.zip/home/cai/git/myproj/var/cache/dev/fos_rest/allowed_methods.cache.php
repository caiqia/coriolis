<?php return array (
  'api_get_count' => 
  array (
    0 => 'GET',
  ),
  'api_get_search' => 
  array (
    0 => 'GET',
  ),
  'api_post' => 
  array (
    0 => 'POST',
    1 => 'PUT',
  ),
  'api_put' => 
  array (
    0 => 'POST',
    1 => 'PUT',
  ),
  'api_patch' => 
  array (
    0 => 'PATCH',
    1 => 'DELETE',
    2 => 'GET',
  ),
  'api_delete' => 
  array (
    0 => 'PATCH',
    1 => 'DELETE',
    2 => 'GET',
  ),
  'api_get' => 
  array (
    0 => 'PATCH',
    1 => 'DELETE',
    2 => 'GET',
  ),
  'api_delete_all' => 
  array (
    0 => 'DELETE',
  ),
  'nelmio_api_doc_index' => 
  array (
    0 => 'GET',
  ),
);
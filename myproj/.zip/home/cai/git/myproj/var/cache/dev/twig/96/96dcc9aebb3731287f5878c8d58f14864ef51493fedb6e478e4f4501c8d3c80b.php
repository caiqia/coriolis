<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_3582d36ffad491803661d708e054de9975ca4393ef03ecd660c249e97c0b4cfb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_073ce670bfc8f5a9d7172f8efe0b0f14d6b9284963189703cd030ef4b5614b9c = $this->env->getExtension("native_profiler");
        $__internal_073ce670bfc8f5a9d7172f8efe0b0f14d6b9284963189703cd030ef4b5614b9c->enter($__internal_073ce670bfc8f5a9d7172f8efe0b0f14d6b9284963189703cd030ef4b5614b9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_073ce670bfc8f5a9d7172f8efe0b0f14d6b9284963189703cd030ef4b5614b9c->leave($__internal_073ce670bfc8f5a9d7172f8efe0b0f14d6b9284963189703cd030ef4b5614b9c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */

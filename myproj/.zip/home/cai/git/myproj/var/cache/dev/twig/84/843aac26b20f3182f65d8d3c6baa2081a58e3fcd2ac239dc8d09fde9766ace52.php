<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_9e6124271876b92ac98579111093d500816549c081c043d53aefec9cf23c2df8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_00d816db070d21766a4903edf6db5e87284411003bec81f98a5052965e2ccb25 = $this->env->getExtension("native_profiler");
        $__internal_00d816db070d21766a4903edf6db5e87284411003bec81f98a5052965e2ccb25->enter($__internal_00d816db070d21766a4903edf6db5e87284411003bec81f98a5052965e2ccb25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_00d816db070d21766a4903edf6db5e87284411003bec81f98a5052965e2ccb25->leave($__internal_00d816db070d21766a4903edf6db5e87284411003bec81f98a5052965e2ccb25_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */

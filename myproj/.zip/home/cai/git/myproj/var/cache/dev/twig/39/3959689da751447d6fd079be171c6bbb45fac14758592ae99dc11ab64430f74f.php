<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_703cff44a5be1cb990ef840e6e53b488165f24ffef33dbe830c769fd7c4db0fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a0fb2197326532590314960efa4414f3f9d067890c0515d4f2ccbaeecb1cf99 = $this->env->getExtension("native_profiler");
        $__internal_6a0fb2197326532590314960efa4414f3f9d067890c0515d4f2ccbaeecb1cf99->enter($__internal_6a0fb2197326532590314960efa4414f3f9d067890c0515d4f2ccbaeecb1cf99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_6a0fb2197326532590314960efa4414f3f9d067890c0515d4f2ccbaeecb1cf99->leave($__internal_6a0fb2197326532590314960efa4414f3f9d067890c0515d4f2ccbaeecb1cf99_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */

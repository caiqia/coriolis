<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_cf87e62f6a77fb20311290cd46d5e7e046e7ba0fd278fe57251da6644cfa2b40 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73726d27904aa3211cb31c5acf59f8d820533df4f803787d659810d8c628bba0 = $this->env->getExtension("native_profiler");
        $__internal_73726d27904aa3211cb31c5acf59f8d820533df4f803787d659810d8c628bba0->enter($__internal_73726d27904aa3211cb31c5acf59f8d820533df4f803787d659810d8c628bba0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_73726d27904aa3211cb31c5acf59f8d820533df4f803787d659810d8c628bba0->leave($__internal_73726d27904aa3211cb31c5acf59f8d820533df4f803787d659810d8c628bba0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */

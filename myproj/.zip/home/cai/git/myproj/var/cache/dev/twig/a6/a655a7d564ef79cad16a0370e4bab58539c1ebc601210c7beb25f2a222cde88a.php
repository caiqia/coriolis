<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_040b0e0d98128cee8e6e56908f26c46900ccf1ba6672eaf8c5d0765a9952aa6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_26f1431951474dabe4e1d789e5f6de450504adc1102a305f3c21437b99d073ad = $this->env->getExtension("native_profiler");
        $__internal_26f1431951474dabe4e1d789e5f6de450504adc1102a305f3c21437b99d073ad->enter($__internal_26f1431951474dabe4e1d789e5f6de450504adc1102a305f3c21437b99d073ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_26f1431951474dabe4e1d789e5f6de450504adc1102a305f3c21437b99d073ad->leave($__internal_26f1431951474dabe4e1d789e5f6de450504adc1102a305f3c21437b99d073ad_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */

<?php

namespace LUCIE\RadiusBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LUCIERadiusBundle extends Bundle
{
}

<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_ee25c3997059bfb78b4f7911f47c8b667559ff38a6ea68256bba07e77d04fcdb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5449764609bc4e04f184c5b50fed6878dd8ce0c3ee67f02d953f6ae0127027bd = $this->env->getExtension("native_profiler");
        $__internal_5449764609bc4e04f184c5b50fed6878dd8ce0c3ee67f02d953f6ae0127027bd->enter($__internal_5449764609bc4e04f184c5b50fed6878dd8ce0c3ee67f02d953f6ae0127027bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_5449764609bc4e04f184c5b50fed6878dd8ce0c3ee67f02d953f6ae0127027bd->leave($__internal_5449764609bc4e04f184c5b50fed6878dd8ce0c3ee67f02d953f6ae0127027bd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */

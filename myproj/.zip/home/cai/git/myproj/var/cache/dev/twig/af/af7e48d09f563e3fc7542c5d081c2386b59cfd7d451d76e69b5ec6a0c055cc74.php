<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_30522a5c63df1b7a2b4e5cb422fc78ca86576203c191b1d054e3edf0c96fb6b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_544925c614a64532c15dc5f8f74cdc31e46ae936d18b7d6861407ebcd46ef3e0 = $this->env->getExtension("native_profiler");
        $__internal_544925c614a64532c15dc5f8f74cdc31e46ae936d18b7d6861407ebcd46ef3e0->enter($__internal_544925c614a64532c15dc5f8f74cdc31e46ae936d18b7d6861407ebcd46ef3e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_544925c614a64532c15dc5f8f74cdc31e46ae936d18b7d6861407ebcd46ef3e0->leave($__internal_544925c614a64532c15dc5f8f74cdc31e46ae936d18b7d6861407ebcd46ef3e0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */

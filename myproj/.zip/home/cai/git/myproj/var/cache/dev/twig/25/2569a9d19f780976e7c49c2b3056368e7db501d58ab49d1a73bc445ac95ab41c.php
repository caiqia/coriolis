<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_3a5426cdf80ebadc922dd9015dd9437a959150fd54e9b1366b23cea619531db3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_965ba6d0c00de6f1109589e8bb34c30a2940d4a2754cb556683d230c7ebdbe34 = $this->env->getExtension("native_profiler");
        $__internal_965ba6d0c00de6f1109589e8bb34c30a2940d4a2754cb556683d230c7ebdbe34->enter($__internal_965ba6d0c00de6f1109589e8bb34c30a2940d4a2754cb556683d230c7ebdbe34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_965ba6d0c00de6f1109589e8bb34c30a2940d4a2754cb556683d230c7ebdbe34->leave($__internal_965ba6d0c00de6f1109589e8bb34c30a2940d4a2754cb556683d230c7ebdbe34_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!$label) { $label = isset($label_format)*/
/*     ? strtr($label_format, array('%name%' => $name, '%id%' => $id))*/
/*     : $view['form']->humanize($name); } ?>*/
/* <button type="<?php echo isset($type) ? $view->escape($type) : 'button' ?>" <?php echo $view['form']->block($form, 'button_attributes') ?>><?php echo $view->escape(false !== $translation_domain ? $view['translator']->trans($label, array(), $translation_domain) : $label) ?></button>*/
/* */

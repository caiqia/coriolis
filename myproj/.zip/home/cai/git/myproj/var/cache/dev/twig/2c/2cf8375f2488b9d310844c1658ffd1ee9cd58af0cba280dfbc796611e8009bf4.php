<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_ad58ab27c6f268b29d83dc55626cd0fa469fcb7cd037fb748e1caea84706daeb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce09340655b4ba06bf2a4662e95ce970ec3fd13794ec48149247c8ca4c0536b6 = $this->env->getExtension("native_profiler");
        $__internal_ce09340655b4ba06bf2a4662e95ce970ec3fd13794ec48149247c8ca4c0536b6->enter($__internal_ce09340655b4ba06bf2a4662e95ce970ec3fd13794ec48149247c8ca4c0536b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_ce09340655b4ba06bf2a4662e95ce970ec3fd13794ec48149247c8ca4c0536b6->leave($__internal_ce09340655b4ba06bf2a4662e95ce970ec3fd13794ec48149247c8ca4c0536b6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */

<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_746ed8b7ce0e393513d9156cad7c090b8fccb6b55369146122fc1178ecbad30d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e53b3c6001681e2766005a59022fa480de41d00d3da3457ea1bc810c6c314c5b = $this->env->getExtension("native_profiler");
        $__internal_e53b3c6001681e2766005a59022fa480de41d00d3da3457ea1bc810c6c314c5b->enter($__internal_e53b3c6001681e2766005a59022fa480de41d00d3da3457ea1bc810c6c314c5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_e53b3c6001681e2766005a59022fa480de41d00d3da3457ea1bc810c6c314c5b->leave($__internal_e53b3c6001681e2766005a59022fa480de41d00d3da3457ea1bc810c6c314c5b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */

<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_e00e33a785c3737410e6a86131f1f8e23fac3574c57584e1e020f3344071ac81 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a3e644cdb3d416ce52f72cf3107bb6ee584b278094ea1ee6dd1bb4c37f98ad16 = $this->env->getExtension("native_profiler");
        $__internal_a3e644cdb3d416ce52f72cf3107bb6ee584b278094ea1ee6dd1bb4c37f98ad16->enter($__internal_a3e644cdb3d416ce52f72cf3107bb6ee584b278094ea1ee6dd1bb4c37f98ad16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_a3e644cdb3d416ce52f72cf3107bb6ee584b278094ea1ee6dd1bb4c37f98ad16->leave($__internal_a3e644cdb3d416ce52f72cf3107bb6ee584b278094ea1ee6dd1bb4c37f98ad16_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}

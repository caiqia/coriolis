<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_66d545d7c5eb9ad2494d33cba73e4da1b284d3043bdb12aeff348d6f713f8574 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_643d6961e236e516e3a548178cf43b95b3e5aed240d0b7cebfc2ec116ceadfb6 = $this->env->getExtension("native_profiler");
        $__internal_643d6961e236e516e3a548178cf43b95b3e5aed240d0b7cebfc2ec116ceadfb6->enter($__internal_643d6961e236e516e3a548178cf43b95b3e5aed240d0b7cebfc2ec116ceadfb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_643d6961e236e516e3a548178cf43b95b3e5aed240d0b7cebfc2ec116ceadfb6->leave($__internal_643d6961e236e516e3a548178cf43b95b3e5aed240d0b7cebfc2ec116ceadfb6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */

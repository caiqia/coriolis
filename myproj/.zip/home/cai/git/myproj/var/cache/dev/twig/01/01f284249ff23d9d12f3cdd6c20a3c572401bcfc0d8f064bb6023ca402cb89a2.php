<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_71145ca19547b217b9695c99de60b4b7f55480392c7049566e112eca4b44e10e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f7916360e95c75675a5a5e65261e26068ec839b7b66476bb8ea3e73a03ece37 = $this->env->getExtension("native_profiler");
        $__internal_0f7916360e95c75675a5a5e65261e26068ec839b7b66476bb8ea3e73a03ece37->enter($__internal_0f7916360e95c75675a5a5e65261e26068ec839b7b66476bb8ea3e73a03ece37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_0f7916360e95c75675a5a5e65261e26068ec839b7b66476bb8ea3e73a03ece37->leave($__internal_0f7916360e95c75675a5a5e65261e26068ec839b7b66476bb8ea3e73a03ece37_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */

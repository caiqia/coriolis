<?php

/* NelmioApiDocBundle:Components:motd.html.twig */
class __TwigTemplate_45664cb19c25e9b3e786bfb9f94fe18977408cff8e343c7599f63b0036f41df9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a49e805e8888f76fa2ea489f12951528552eb6334d40347faad0f4e41504fbc = $this->env->getExtension("native_profiler");
        $__internal_2a49e805e8888f76fa2ea489f12951528552eb6334d40347faad0f4e41504fbc->enter($__internal_2a49e805e8888f76fa2ea489f12951528552eb6334d40347faad0f4e41504fbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NelmioApiDocBundle:Components:motd.html.twig"));

        // line 1
        echo "<div class=\"motd\"></div>
";
        
        $__internal_2a49e805e8888f76fa2ea489f12951528552eb6334d40347faad0f4e41504fbc->leave($__internal_2a49e805e8888f76fa2ea489f12951528552eb6334d40347faad0f4e41504fbc_prof);

    }

    public function getTemplateName()
    {
        return "NelmioApiDocBundle:Components:motd.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div class="motd"></div>*/
/* */

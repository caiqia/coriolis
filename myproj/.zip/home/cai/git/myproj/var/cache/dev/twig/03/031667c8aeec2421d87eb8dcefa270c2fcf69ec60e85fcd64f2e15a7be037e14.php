<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_2080f0bd94ce058c9ff290f15565da938706b141a7d28c07dcfc6471ca389549 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d4eef3e7131879edce2f38f1f494858e6d54d5474d4a2561e46d3be57b49853 = $this->env->getExtension("native_profiler");
        $__internal_9d4eef3e7131879edce2f38f1f494858e6d54d5474d4a2561e46d3be57b49853->enter($__internal_9d4eef3e7131879edce2f38f1f494858e6d54d5474d4a2561e46d3be57b49853_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_9d4eef3e7131879edce2f38f1f494858e6d54d5474d4a2561e46d3be57b49853->leave($__internal_9d4eef3e7131879edce2f38f1f494858e6d54d5474d4a2561e46d3be57b49853_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */

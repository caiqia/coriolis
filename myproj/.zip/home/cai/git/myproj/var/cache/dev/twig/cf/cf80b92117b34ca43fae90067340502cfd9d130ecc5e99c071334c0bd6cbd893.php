<?php

/* NelmioApiDocBundle::resource.html.twig */
class __TwigTemplate_3c3d5fc573c5b6d95d55d4830f1a2b41198c8e43b2070b677999b97e6b24f282 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NelmioApiDocBundle::layout.html.twig", "NelmioApiDocBundle::resource.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NelmioApiDocBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b7936f6570c2d0a17849cd28c282420153a07db0641740a63f5dda402783f38 = $this->env->getExtension("native_profiler");
        $__internal_3b7936f6570c2d0a17849cd28c282420153a07db0641740a63f5dda402783f38->enter($__internal_3b7936f6570c2d0a17849cd28c282420153a07db0641740a63f5dda402783f38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NelmioApiDocBundle::resource.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3b7936f6570c2d0a17849cd28c282420153a07db0641740a63f5dda402783f38->leave($__internal_3b7936f6570c2d0a17849cd28c282420153a07db0641740a63f5dda402783f38_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_988fc1348037bc229a21b865e8dc1c57e30af69ab3ba5106538e5ca1f707614c = $this->env->getExtension("native_profiler");
        $__internal_988fc1348037bc229a21b865e8dc1c57e30af69ab3ba5106538e5ca1f707614c->enter($__internal_988fc1348037bc229a21b865e8dc1c57e30af69ab3ba5106538e5ca1f707614c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <li class=\"resource\">
        <ul class=\"endpoints\">
            <li class=\"endpoint\">
                <ul class=\"operations\">
                    ";
        // line 8
        $this->loadTemplate("NelmioApiDocBundle::method.html.twig", "NelmioApiDocBundle::resource.html.twig", 8)->display($context);
        // line 9
        echo "                </ul>
            </li>
        </ul>
    </li>
";
        
        $__internal_988fc1348037bc229a21b865e8dc1c57e30af69ab3ba5106538e5ca1f707614c->leave($__internal_988fc1348037bc229a21b865e8dc1c57e30af69ab3ba5106538e5ca1f707614c_prof);

    }

    public function getTemplateName()
    {
        return "NelmioApiDocBundle::resource.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 9,  46 => 8,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "NelmioApiDocBundle::layout.html.twig" %}*/
/* */
/* {% block content %}*/
/*     <li class="resource">*/
/*         <ul class="endpoints">*/
/*             <li class="endpoint">*/
/*                 <ul class="operations">*/
/*                     {% include 'NelmioApiDocBundle::method.html.twig' %}*/
/*                 </ul>*/
/*             </li>*/
/*         </ul>*/
/*     </li>*/
/* {% endblock content %}*/
/* */

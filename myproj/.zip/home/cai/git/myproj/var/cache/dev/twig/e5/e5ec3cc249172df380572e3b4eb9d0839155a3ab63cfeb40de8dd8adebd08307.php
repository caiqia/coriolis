<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_b643a53e96813feca1ccc3a5f91943cbbea9722a4a5fa098b8218cb194fb004a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_befe7f2c87dd3c3907934b5960ce436aa9eae0ade739ddc0e41a390540b24f76 = $this->env->getExtension("native_profiler");
        $__internal_befe7f2c87dd3c3907934b5960ce436aa9eae0ade739ddc0e41a390540b24f76->enter($__internal_befe7f2c87dd3c3907934b5960ce436aa9eae0ade739ddc0e41a390540b24f76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_befe7f2c87dd3c3907934b5960ce436aa9eae0ade739ddc0e41a390540b24f76->leave($__internal_befe7f2c87dd3c3907934b5960ce436aa9eae0ade739ddc0e41a390540b24f76_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */

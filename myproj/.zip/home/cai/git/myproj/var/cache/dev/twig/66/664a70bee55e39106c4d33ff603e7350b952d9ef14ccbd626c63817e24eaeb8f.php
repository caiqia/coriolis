<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_92eec0a550de175702b201af9286b45c2a89b7755cb90f67b7669597ae15cb0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9db0cc3fb507b9fd54ed59b477730c036d745045a9fdbe56d9e3657422033f69 = $this->env->getExtension("native_profiler");
        $__internal_9db0cc3fb507b9fd54ed59b477730c036d745045a9fdbe56d9e3657422033f69->enter($__internal_9db0cc3fb507b9fd54ed59b477730c036d745045a9fdbe56d9e3657422033f69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_9db0cc3fb507b9fd54ed59b477730c036d745045a9fdbe56d9e3657422033f69->leave($__internal_9db0cc3fb507b9fd54ed59b477730c036d745045a9fdbe56d9e3657422033f69_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */

<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_bb3b1cc77623de5b1c57d8d6e1ef56d33fc2ce5d3f29539d414bdd2e3755d9f7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_155d99cce33b51bcc91ba4f4e3d833234806267f5b5d3b79ff0ebf3cd921aa6b = $this->env->getExtension("native_profiler");
        $__internal_155d99cce33b51bcc91ba4f4e3d833234806267f5b5d3b79ff0ebf3cd921aa6b->enter($__internal_155d99cce33b51bcc91ba4f4e3d833234806267f5b5d3b79ff0ebf3cd921aa6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"
<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_155d99cce33b51bcc91ba4f4e3d833234806267f5b5d3b79ff0ebf3cd921aa6b->leave($__internal_155d99cce33b51bcc91ba4f4e3d833234806267f5b5d3b79ff0ebf3cd921aa6b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* id="<?php echo $view->escape($id) ?>" name="<?php echo $view->escape($full_name) ?>"*/
/* <?php if ($disabled): ?>disabled="disabled" <?php endif ?>*/
/* <?php foreach ($choice_attr as $k => $v): ?>*/
/* <?php if ($v === true): ?>*/
/* <?php printf('%s="%s" ', $view->escape($k), $view->escape($k)) ?>*/
/* <?php elseif ($v !== false): ?>*/
/* <?php printf('%s="%s" ', $view->escape($k), $view->escape($v)) ?>*/
/* <?php endif ?>*/
/* <?php endforeach ?>*/
/* */

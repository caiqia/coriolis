<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_7e909f32e516d8c1aa46394df121e1a5c18ffff33c9e4c02f978e9911e65c069 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_887fd1b04552b3df646df4d9d90cc7cc70e092a11eb92ab47d09e54e23993506 = $this->env->getExtension("native_profiler");
        $__internal_887fd1b04552b3df646df4d9d90cc7cc70e092a11eb92ab47d09e54e23993506->enter($__internal_887fd1b04552b3df646df4d9d90cc7cc70e092a11eb92ab47d09e54e23993506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_887fd1b04552b3df646df4d9d90cc7cc70e092a11eb92ab47d09e54e23993506->leave($__internal_887fd1b04552b3df646df4d9d90cc7cc70e092a11eb92ab47d09e54e23993506_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */

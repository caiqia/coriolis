<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_176d9581722eeff4fe2561da71cc344d2a4d0508c6048a31fc64f957bccaf669 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b9d5d3e95f4de95bfbfa157c64eab4090c9874bd168a40ab3f899318f4c6dcc = $this->env->getExtension("native_profiler");
        $__internal_3b9d5d3e95f4de95bfbfa157c64eab4090c9874bd168a40ab3f899318f4c6dcc->enter($__internal_3b9d5d3e95f4de95bfbfa157c64eab4090c9874bd168a40ab3f899318f4c6dcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_3b9d5d3e95f4de95bfbfa157c64eab4090c9874bd168a40ab3f899318f4c6dcc->leave($__internal_3b9d5d3e95f4de95bfbfa157c64eab4090c9874bd168a40ab3f899318f4c6dcc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */

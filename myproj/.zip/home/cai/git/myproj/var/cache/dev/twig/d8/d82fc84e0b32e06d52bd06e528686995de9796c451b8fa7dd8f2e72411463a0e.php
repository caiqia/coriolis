<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_8596acc8acbd8c9d529d7e5bcde712c8964f3f6139a55a4950e10c84c283d388 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78486d045ad0223f08545f01c307b67dcefeff28afaf0a630367d38f4f4fe886 = $this->env->getExtension("native_profiler");
        $__internal_78486d045ad0223f08545f01c307b67dcefeff28afaf0a630367d38f4f4fe886->enter($__internal_78486d045ad0223f08545f01c307b67dcefeff28afaf0a630367d38f4f4fe886_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_78486d045ad0223f08545f01c307b67dcefeff28afaf0a630367d38f4f4fe886->leave($__internal_78486d045ad0223f08545f01c307b67dcefeff28afaf0a630367d38f4f4fe886_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */

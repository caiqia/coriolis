<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_6995f676f5c4b6c1e73f84d935b1b4de6348374fa9a6c50597a2e4f0c10ae7de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3cf916afcd8ef6a3a031deeb8f64d0397bde4fd040a397736305242d87345838 = $this->env->getExtension("native_profiler");
        $__internal_3cf916afcd8ef6a3a031deeb8f64d0397bde4fd040a397736305242d87345838->enter($__internal_3cf916afcd8ef6a3a031deeb8f64d0397bde4fd040a397736305242d87345838_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_3cf916afcd8ef6a3a031deeb8f64d0397bde4fd040a397736305242d87345838->leave($__internal_3cf916afcd8ef6a3a031deeb8f64d0397bde4fd040a397736305242d87345838_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */

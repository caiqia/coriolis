<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_77af4708b86554c642221db7c42932f3a44f200621e05ca895eb7bebb74e1823 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88d0c31b9d361777b0755530763d03f2cbfee237ea9d2d201d79c0d4ae182326 = $this->env->getExtension("native_profiler");
        $__internal_88d0c31b9d361777b0755530763d03f2cbfee237ea9d2d201d79c0d4ae182326->enter($__internal_88d0c31b9d361777b0755530763d03f2cbfee237ea9d2d201d79c0d4ae182326_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_88d0c31b9d361777b0755530763d03f2cbfee237ea9d2d201d79c0d4ae182326->leave($__internal_88d0c31b9d361777b0755530763d03f2cbfee237ea9d2d201d79c0d4ae182326_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */

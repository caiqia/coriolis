<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_beb6e3092c30aeec12360b8c03bfcc0acb9f93698e61611a46594880fb779dc4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5cfe97ffa98fc3fe67f473ebd948ac3ad95672124dbf7366cfd843819eb58540 = $this->env->getExtension("native_profiler");
        $__internal_5cfe97ffa98fc3fe67f473ebd948ac3ad95672124dbf7366cfd843819eb58540->enter($__internal_5cfe97ffa98fc3fe67f473ebd948ac3ad95672124dbf7366cfd843819eb58540_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_5cfe97ffa98fc3fe67f473ebd948ac3ad95672124dbf7366cfd843819eb58540->leave($__internal_5cfe97ffa98fc3fe67f473ebd948ac3ad95672124dbf7366cfd843819eb58540_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */

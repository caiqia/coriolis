<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_9936c5cfc2ce2f3016c21dccffc1accc0617b856e977ab0864dac21fdaa40351 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_392eb97da97679173ee1ef68f76d140f772aed1d249f94a3179ed2424ed039dd = $this->env->getExtension("native_profiler");
        $__internal_392eb97da97679173ee1ef68f76d140f772aed1d249f94a3179ed2424ed039dd->enter($__internal_392eb97da97679173ee1ef68f76d140f772aed1d249f94a3179ed2424ed039dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_392eb97da97679173ee1ef68f76d140f772aed1d249f94a3179ed2424ed039dd->leave($__internal_392eb97da97679173ee1ef68f76d140f772aed1d249f94a3179ed2424ed039dd_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */

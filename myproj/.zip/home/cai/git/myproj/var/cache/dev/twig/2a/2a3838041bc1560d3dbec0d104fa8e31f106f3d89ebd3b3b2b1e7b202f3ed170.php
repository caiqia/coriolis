<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_7afcac38cd5231ff43fe5d29dd719cb32ca3eaf82e40fecc091ce32dbd309183 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2da04c7d3b2c3e8c9b7c8f650fd5139b4c5b4d823c04466130cec16307abf903 = $this->env->getExtension("native_profiler");
        $__internal_2da04c7d3b2c3e8c9b7c8f650fd5139b4c5b4d823c04466130cec16307abf903->enter($__internal_2da04c7d3b2c3e8c9b7c8f650fd5139b4c5b4d823c04466130cec16307abf903_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_2da04c7d3b2c3e8c9b7c8f650fd5139b4c5b4d823c04466130cec16307abf903->leave($__internal_2da04c7d3b2c3e8c9b7c8f650fd5139b4c5b4d823c04466130cec16307abf903_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */

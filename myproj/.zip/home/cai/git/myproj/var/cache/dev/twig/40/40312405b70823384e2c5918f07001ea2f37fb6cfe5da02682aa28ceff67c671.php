<?php

/* LUCIERadiusBundle:Default:index.html.twig */
class __TwigTemplate_bf6466c0b293d1afe10f76f007110121a89ed1c64f06b32af38187a6f05736ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a6a178bfdc969586747989f2a1b1699c0ad72e7c57abfb263933b501ec77bd39 = $this->env->getExtension("native_profiler");
        $__internal_a6a178bfdc969586747989f2a1b1699c0ad72e7c57abfb263933b501ec77bd39->enter($__internal_a6a178bfdc969586747989f2a1b1699c0ad72e7c57abfb263933b501ec77bd39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "LUCIERadiusBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_a6a178bfdc969586747989f2a1b1699c0ad72e7c57abfb263933b501ec77bd39->leave($__internal_a6a178bfdc969586747989f2a1b1699c0ad72e7c57abfb263933b501ec77bd39_prof);

    }

    public function getTemplateName()
    {
        return "LUCIERadiusBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */

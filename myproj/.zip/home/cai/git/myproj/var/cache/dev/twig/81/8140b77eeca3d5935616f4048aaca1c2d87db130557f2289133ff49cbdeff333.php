<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_8cf6ae7a2b65fd5822ca82c259160d6e588d74f731c15fd3d845435955e9d2c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ca93a2c18a0e9368b07c56d8254dd821345ef92dbd44bdd92c30f3bd2751e10 = $this->env->getExtension("native_profiler");
        $__internal_5ca93a2c18a0e9368b07c56d8254dd821345ef92dbd44bdd92c30f3bd2751e10->enter($__internal_5ca93a2c18a0e9368b07c56d8254dd821345ef92dbd44bdd92c30f3bd2751e10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_5ca93a2c18a0e9368b07c56d8254dd821345ef92dbd44bdd92c30f3bd2751e10->leave($__internal_5ca93a2c18a0e9368b07c56d8254dd821345ef92dbd44bdd92c30f3bd2751e10_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */

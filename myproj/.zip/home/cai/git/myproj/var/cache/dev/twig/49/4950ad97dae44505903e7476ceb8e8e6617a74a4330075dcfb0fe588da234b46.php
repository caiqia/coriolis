<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_fab6ee88ee02eaf51e1e795250db19c3cf0ae2dc536a370b612ea46ed56eef6a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12e6c8a83cefb7f7a37886a0445dae44e03ef9947bbe708da82df0faf9ef419e = $this->env->getExtension("native_profiler");
        $__internal_12e6c8a83cefb7f7a37886a0445dae44e03ef9947bbe708da82df0faf9ef419e->enter($__internal_12e6c8a83cefb7f7a37886a0445dae44e03ef9947bbe708da82df0faf9ef419e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_12e6c8a83cefb7f7a37886a0445dae44e03ef9947bbe708da82df0faf9ef419e->leave($__internal_12e6c8a83cefb7f7a37886a0445dae44e03ef9947bbe708da82df0faf9ef419e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */

<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_e5f02c735ecda73ed802bd0529d9fe400c4ce9ce80d46df5eaa6acbe31636183 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97dc2d66b508d4eb7fb41a93bc88e84583f9e017f380b935f85dfe9fd9376263 = $this->env->getExtension("native_profiler");
        $__internal_97dc2d66b508d4eb7fb41a93bc88e84583f9e017f380b935f85dfe9fd9376263->enter($__internal_97dc2d66b508d4eb7fb41a93bc88e84583f9e017f380b935f85dfe9fd9376263_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_97dc2d66b508d4eb7fb41a93bc88e84583f9e017f380b935f85dfe9fd9376263->leave($__internal_97dc2d66b508d4eb7fb41a93bc88e84583f9e017f380b935f85dfe9fd9376263_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */

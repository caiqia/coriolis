<?php

namespace LUCIE\RadiusBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class RadControllerTest extends WebTestCase
{
}

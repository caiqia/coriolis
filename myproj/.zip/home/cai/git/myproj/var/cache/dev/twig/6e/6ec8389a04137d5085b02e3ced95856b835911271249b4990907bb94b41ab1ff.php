<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_c6460aa55130c94b993eb6c507395035cabb632ed1f4f743201fbdfe254b3242 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f3d509f9b2b881a13742fe833e9a71ab9bd58d6f878e56bc6fda188123de7e8 = $this->env->getExtension("native_profiler");
        $__internal_4f3d509f9b2b881a13742fe833e9a71ab9bd58d6f878e56bc6fda188123de7e8->enter($__internal_4f3d509f9b2b881a13742fe833e9a71ab9bd58d6f878e56bc6fda188123de7e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_4f3d509f9b2b881a13742fe833e9a71ab9bd58d6f878e56bc6fda188123de7e8->leave($__internal_4f3d509f9b2b881a13742fe833e9a71ab9bd58d6f878e56bc6fda188123de7e8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */

<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_c2adbda3bb7a94def10ab6afb77f699b61c33eb1669a2be4179cf8ef82de23bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a217410abfb2b5103ddfc8e6a2555462a2d27234fdb936b16078f80ddd0881de = $this->env->getExtension("native_profiler");
        $__internal_a217410abfb2b5103ddfc8e6a2555462a2d27234fdb936b16078f80ddd0881de->enter($__internal_a217410abfb2b5103ddfc8e6a2555462a2d27234fdb936b16078f80ddd0881de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_a217410abfb2b5103ddfc8e6a2555462a2d27234fdb936b16078f80ddd0881de->leave($__internal_a217410abfb2b5103ddfc8e6a2555462a2d27234fdb936b16078f80ddd0881de_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */

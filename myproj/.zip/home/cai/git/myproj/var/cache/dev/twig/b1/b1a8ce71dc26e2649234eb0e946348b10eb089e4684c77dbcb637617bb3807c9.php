<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_aec56ec4163b7534d3e8efbddd5663d5da59f0cf120ee4be8d4811be5d20882d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5c62de896661115d211f077b1e56cb1b7e32718261f02ba46f895e24620ac66 = $this->env->getExtension("native_profiler");
        $__internal_f5c62de896661115d211f077b1e56cb1b7e32718261f02ba46f895e24620ac66->enter($__internal_f5c62de896661115d211f077b1e56cb1b7e32718261f02ba46f895e24620ac66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_f5c62de896661115d211f077b1e56cb1b7e32718261f02ba46f895e24620ac66->leave($__internal_f5c62de896661115d211f077b1e56cb1b7e32718261f02ba46f895e24620ac66_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */

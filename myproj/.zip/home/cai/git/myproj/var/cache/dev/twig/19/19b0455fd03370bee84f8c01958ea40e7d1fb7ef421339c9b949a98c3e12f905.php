<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_ec37ea523a92008498918836efa1d87d6b8aea5fa2142c9f97f5a5d81196c34c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b71bf052b3393757969b34aa007454f60d27cb534149752099f89ec0ec5a83d3 = $this->env->getExtension("native_profiler");
        $__internal_b71bf052b3393757969b34aa007454f60d27cb534149752099f89ec0ec5a83d3->enter($__internal_b71bf052b3393757969b34aa007454f60d27cb534149752099f89ec0ec5a83d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_b71bf052b3393757969b34aa007454f60d27cb534149752099f89ec0ec5a83d3->leave($__internal_b71bf052b3393757969b34aa007454f60d27cb534149752099f89ec0ec5a83d3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */

<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_4c30719174681c2ce94465654c756bf9b221dc2e3fc72a2742140fb5880e09bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f3353bc7c2f09ef119eac42f2491037a090c2c512909674e27ebdf6e24330df3 = $this->env->getExtension("native_profiler");
        $__internal_f3353bc7c2f09ef119eac42f2491037a090c2c512909674e27ebdf6e24330df3->enter($__internal_f3353bc7c2f09ef119eac42f2491037a090c2c512909674e27ebdf6e24330df3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_f3353bc7c2f09ef119eac42f2491037a090c2c512909674e27ebdf6e24330df3->leave($__internal_f3353bc7c2f09ef119eac42f2491037a090c2c512909674e27ebdf6e24330df3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */

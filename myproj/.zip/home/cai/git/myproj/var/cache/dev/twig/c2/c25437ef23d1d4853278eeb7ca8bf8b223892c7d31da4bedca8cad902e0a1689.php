<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_8fd952d35772f52acbc8598cf8e62f16fc3472f5ae6bc8862a188ebbea8473fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_036b74ad5c7e7c8bbb28f3fa1ecdca9cb4751b648a5d6ed708b923129325d60f = $this->env->getExtension("native_profiler");
        $__internal_036b74ad5c7e7c8bbb28f3fa1ecdca9cb4751b648a5d6ed708b923129325d60f->enter($__internal_036b74ad5c7e7c8bbb28f3fa1ecdca9cb4751b648a5d6ed708b923129325d60f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_036b74ad5c7e7c8bbb28f3fa1ecdca9cb4751b648a5d6ed708b923129325d60f->leave($__internal_036b74ad5c7e7c8bbb28f3fa1ecdca9cb4751b648a5d6ed708b923129325d60f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */

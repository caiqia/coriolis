<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_140885c6941b04f23d0b6df0ce5d64bc493b78ac9b546cb4d6c7197b26a22c87 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c69eea9e2f53c94f9517a8876899cd4a62f883024b393d83ee7d8fc22d643780 = $this->env->getExtension("native_profiler");
        $__internal_c69eea9e2f53c94f9517a8876899cd4a62f883024b393d83ee7d8fc22d643780->enter($__internal_c69eea9e2f53c94f9517a8876899cd4a62f883024b393d83ee7d8fc22d643780_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_c69eea9e2f53c94f9517a8876899cd4a62f883024b393d83ee7d8fc22d643780->leave($__internal_c69eea9e2f53c94f9517a8876899cd4a62f883024b393d83ee7d8fc22d643780_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */

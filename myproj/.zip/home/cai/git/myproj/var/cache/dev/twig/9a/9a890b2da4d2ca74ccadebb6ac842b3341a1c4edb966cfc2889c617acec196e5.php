<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_62e79dc97e7fea01ab41a612e6f1d15e9c276843de30019fd799d2babf138160 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1893592252c176ed127b720d43968a636803062e7e0d725e5a5d7b0749329b59 = $this->env->getExtension("native_profiler");
        $__internal_1893592252c176ed127b720d43968a636803062e7e0d725e5a5d7b0749329b59->enter($__internal_1893592252c176ed127b720d43968a636803062e7e0d725e5a5d7b0749329b59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_1893592252c176ed127b720d43968a636803062e7e0d725e5a5d7b0749329b59->leave($__internal_1893592252c176ed127b720d43968a636803062e7e0d725e5a5d7b0749329b59_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_6fa37b5cedbf4e6e364dbae50069f2208c5d9785b46436f498a9e167aca834d5 = $this->env->getExtension("native_profiler");
        $__internal_6fa37b5cedbf4e6e364dbae50069f2208c5d9785b46436f498a9e167aca834d5->enter($__internal_6fa37b5cedbf4e6e364dbae50069f2208c5d9785b46436f498a9e167aca834d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_6fa37b5cedbf4e6e364dbae50069f2208c5d9785b46436f498a9e167aca834d5->leave($__internal_6fa37b5cedbf4e6e364dbae50069f2208c5d9785b46436f498a9e167aca834d5_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */

<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_f3eb9a5609a45a8f5b6028d3ac72973bb21962bb0ef59d5febc27a8f23647c19 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0cbd7de127cf8b4c47403aac10991e0c4ca0bc5b5471f4865754e6cdb0eec4cf = $this->env->getExtension("native_profiler");
        $__internal_0cbd7de127cf8b4c47403aac10991e0c4ca0bc5b5471f4865754e6cdb0eec4cf->enter($__internal_0cbd7de127cf8b4c47403aac10991e0c4ca0bc5b5471f4865754e6cdb0eec4cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_0cbd7de127cf8b4c47403aac10991e0c4ca0bc5b5471f4865754e6cdb0eec4cf->leave($__internal_0cbd7de127cf8b4c47403aac10991e0c4ca0bc5b5471f4865754e6cdb0eec4cf_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */

<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_1ec8693d7d5c347830ddde2d8e632d7cbca6daaa04a4abb767a8b9f6d0dab41d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_59cacde0e63e90e9a23c60b2c72a58cb22de88a09627a1d47edaa7827cf3de98 = $this->env->getExtension("native_profiler");
        $__internal_59cacde0e63e90e9a23c60b2c72a58cb22de88a09627a1d47edaa7827cf3de98->enter($__internal_59cacde0e63e90e9a23c60b2c72a58cb22de88a09627a1d47edaa7827cf3de98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_59cacde0e63e90e9a23c60b2c72a58cb22de88a09627a1d47edaa7827cf3de98->leave($__internal_59cacde0e63e90e9a23c60b2c72a58cb22de88a09627a1d47edaa7827cf3de98_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */

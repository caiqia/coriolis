<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_2f160f954329059da05de55bc38844a7fbffa12139b4c03092c674ebede32884 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b1c3200dceb6ffcdab06d3420abb6e6ff3fab5b22e55ea46a17fdfa2bd2b281a = $this->env->getExtension("native_profiler");
        $__internal_b1c3200dceb6ffcdab06d3420abb6e6ff3fab5b22e55ea46a17fdfa2bd2b281a->enter($__internal_b1c3200dceb6ffcdab06d3420abb6e6ff3fab5b22e55ea46a17fdfa2bd2b281a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_b1c3200dceb6ffcdab06d3420abb6e6ff3fab5b22e55ea46a17fdfa2bd2b281a->leave($__internal_b1c3200dceb6ffcdab06d3420abb6e6ff3fab5b22e55ea46a17fdfa2bd2b281a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */

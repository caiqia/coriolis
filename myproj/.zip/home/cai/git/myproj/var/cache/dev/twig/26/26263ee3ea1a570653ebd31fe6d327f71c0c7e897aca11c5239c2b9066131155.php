<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_ad8c4b43f5a4f74e96e27332dd541269290a95433c9f53d467ea00c5f33718e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0582399a6745354824ee212ddea8d1b5a4c392217b00884f78771fc00e04b8a9 = $this->env->getExtension("native_profiler");
        $__internal_0582399a6745354824ee212ddea8d1b5a4c392217b00884f78771fc00e04b8a9->enter($__internal_0582399a6745354824ee212ddea8d1b5a4c392217b00884f78771fc00e04b8a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_0582399a6745354824ee212ddea8d1b5a4c392217b00884f78771fc00e04b8a9->leave($__internal_0582399a6745354824ee212ddea8d1b5a4c392217b00884f78771fc00e04b8a9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
